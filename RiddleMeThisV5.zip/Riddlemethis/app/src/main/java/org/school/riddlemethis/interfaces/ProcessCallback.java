package org.school.riddlemethis.interfaces;

public interface ProcessCallback {
    void onItemClicked(int level_no,boolean level_statusOpen);
}
