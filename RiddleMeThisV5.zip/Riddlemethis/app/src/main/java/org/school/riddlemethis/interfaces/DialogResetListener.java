package org.school.riddlemethis.interfaces;

public interface DialogResetListener {
    void onResetCalled();
}
