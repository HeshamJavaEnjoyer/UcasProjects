package org.school.riddlemethis.interfaces;

public interface DialogTimeOutCallback {
    void onClickForTimeOut();
}
