package org.school.riddlemethis.interfaces;

public interface DialogListener {
    void onClickForWrongAnswer();

    void onClickForSkippedDialog();
}
