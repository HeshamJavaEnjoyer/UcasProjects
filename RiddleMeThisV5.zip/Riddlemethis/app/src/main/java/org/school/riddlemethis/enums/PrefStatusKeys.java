package org.school.riddlemethis.enums;

public enum PrefStatusKeys {
    riddles_answered_count, r_ans_right_count, r_ans_wrong_count, l_solved_count
}
