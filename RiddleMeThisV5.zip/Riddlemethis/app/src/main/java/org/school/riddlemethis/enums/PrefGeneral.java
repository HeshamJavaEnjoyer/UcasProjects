package org.school.riddlemethis.enums;

public enum PrefGeneral {
    switchCase, switchCaseNotification
}
