package org.school.riddlemethis.enums;

public enum PrefUserKeys {
    score, user_name, email, birthdate, gender, country
}
